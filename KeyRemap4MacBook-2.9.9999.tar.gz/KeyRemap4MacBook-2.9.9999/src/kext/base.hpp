#ifndef BASE_HPP
#define BASE_HPP

#include <mach/mach_types.h>
#define protected public // A hack for access private member of IOHIKeyboard
#include <IOKit/hidsystem/IOHIKeyboard.h>
#undef protected

#endif
