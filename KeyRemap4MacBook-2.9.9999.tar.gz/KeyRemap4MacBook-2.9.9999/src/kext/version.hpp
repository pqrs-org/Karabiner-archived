char * const config_version = "2.9.9999";
